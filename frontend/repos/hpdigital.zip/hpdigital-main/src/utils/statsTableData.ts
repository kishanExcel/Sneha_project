export const employees = [
    {
        name: "Handym...",
        totalRating: 13.8,
        averageRating: 36,
        tasksRequested: 5,
        tasksCompleted: "Roofing Contractor",
        additional: "Contractor Siding contractor Construction company",
    },
    {
        name: "Roof Co..",
        totalRating: 9.8,
        averageRating: 112,
        tasksRequested: 4.8,
        tasksCompleted: "Roofing Contractor",
        additional: "General Contractor Roofing contractor",
    },
    {
        name: "Roofing...",
        totalRating: 10.3,
        averageRating: 47,
        tasksRequested: 5,
        tasksCompleted: "Roofing Contractor",
        additional: "Contractor Roofing contractor",
    },

];

