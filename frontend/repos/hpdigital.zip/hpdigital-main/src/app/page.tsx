export default function Page() {
  return (
    <>
      <div className="text-3xl font-bold ">Home Page</div>
    </>
  );
}
