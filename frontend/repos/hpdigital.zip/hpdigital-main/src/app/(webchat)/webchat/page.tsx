import WebChat from "@/components/WebChat";
export default function Page() {
  return (
    <div>
      <WebChat />
    </div>
  );
}
